define(['jquery', 'utility'], function(jquery, utility){
	var animateVisibility = utility.animateVisibility;
	jquery(document).ready(function($){
		$(".js.csstransitions").addClass("visible");
		$(".item_container input[type=radio]").attr("ng-change", "loadNextStep()");
		$("#accountInput, #vatInput, #vat_decision").addClass("hide invisible slidein_top");
		animateVisibility("#accountInput, #vatInput, #vat_decision", "hide invisible slidein_top", "hide" );
	});

});