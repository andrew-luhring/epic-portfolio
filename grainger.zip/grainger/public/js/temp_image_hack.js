jQuery(document).ready(function($){
    "use strict";
    // TODO: do this in jsp when you figure out... how.
    $("#minicart_data > img").addClass("cart top_cart icon").attr("src", "https://s3-us-west-2.amazonaws.com/s.cdpn.io/105990/empty-cart-dark.png");
});