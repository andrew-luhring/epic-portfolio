/**
 * @fileoverview Just a spike test
 * @copyright none.
 * @author Andrew Luhring <andrew.luhring@grainger.com>
 * @license grainger
 *
 * @module tests/_testing_jsdoc
 */


"use strict";


/**
 * Test
 * A dummy function which tests to make sure jsdoc is working.
 * @constructor
 * @param prop - The property to add
 * @returns {Test} - an object with the property added
 */
function Test(prop) {
    this[prop] = prop;
    return this;
}

var test = new Test("width");

console.log(test);

