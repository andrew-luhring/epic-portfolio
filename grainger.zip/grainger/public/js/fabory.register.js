

function displayVatAccount() {
	if ($("input[id='account_accountExisted']:checked").val() === "true") {
		$('#accountInput').show();
		$('#vatInput').hide();
	} else {
		$('#accountInput').hide();
		$('#vatInput').show();
	}
}


function enableInvoiceAddress() {
	$("#company_invoiceName").val($("#company_companyName").val());
	$("#company_invoiceAddress").val($("#company_companyAddress").val());
	$("#company_invoiceCity").val($("#company_companyCity").val());
	if ($("#company_companyRegion").length > 0) {
		$("#company_invoiceRegion").val($("#company_companyRegion").val());
	}
	$("#company_invoicePostalCode").val($("#company_companyPostalCode").val());
	$("#company_invoiceCountry").val($("#company_companyCountry").val());
}

function disableInvoiceAddress() {
	$("#company_invoiceName").val("");
	$("#company_invoiceAddress").val("");
	$("#company_invoiceCity").val("");
	if ($("#company_invoiceRegion").length>0) {
		$("#company_invoiceRegion").val("");
	}
	$("#company_invoicePostalCode").val("");
}

function toggleInvoiceAddress() {
	if ($("input[id='company_useSameAsCompany']:checked").val() === "true") {
		enableInvoiceAddress();
	} else {
		disableInvoiceAddress();
	}
}

function hideShowVatNumberInput() {
	if ($("#account_companyCountry").val() === 'US' || $("#account_companyCountry").val() === 'CA' || $("#account_companyCountry").val() === 'GB' || $("#account_companyCountry").val() === '') {
$("#vatNumberInput").hide();
	} else {
		$("#vatNumberInput").show();
	}
}

ACC.bindRegisterEventHandler = {
	bindAll: function () {
		$("input[type='radio']").change(function() {
			if ($(this).attr('id') === 'account_accountExisted') {
				displayVatAccount();
			}
		});
		
		$("#account_noVatNumber").click(function() {
			if ($(this).attr('checked')) {
				$("#account_vatNumber").val("");
				$("#account_vatNumber").prop("disabled",true);
			} else {
				$("#account_vatNumber").prop("disabled",false);
			}
		});
	
		$("#company_useSameAsCompany").click(function() {
			if ($(this).attr('checked')) {
				enableInvoiceAddress();
			} else {
				disableInvoiceAddress();
			}
		});
	
		$("#account_companyCountry").change(function() {
			hideShowVatNumberInput();
		});
	
		$("#company_companyName").change(function() {
			if ($("#company_useSameAsCompany").attr('checked')) {
				$("#company_invoiceName").val($("#company_companyName").val());
			}
		});
	
		$("#company_companyAddress").change(function() {
			if ($("#company_useSameAsCompany").attr('checked')) {
				$("#company_invoiceAddress").val($("#company_companyAddress").val());
			}
		});
	
		$("#company_companyCity").change(function() {
			if ($("#company_useSameAsCompany").attr('checked')) {
				$("#company_invoiceCity").val($("#company_companyCity").val());
			}
		});
	
		$("#company_companyRegion").change(function() {
			if ($("#company_useSameAsCompany").attr('checked')) {	
				$("#company_invoiceRegion").val($("#company_companyRegion").val());
			}
		});
 		
		$("#company_companyCountry").change(function() {
			$("form#compInfoTabForm").append('<input id="countryChanged" value="true" name="countryChanged"/>').submit();
		});
		
		$("#company_companyPostalCode").change(function() {
			if ($("#company_useSameAsCompany").attr('checked')) {
				$("#company_invoicePostalCode").val($("#company_companyPostalCode").val());
			}
		});
	
		$('#userCompanyInfoTab').tabs().addClass('ui-tabs-vertical ui-helper-clearfix');
		$("#userCompanyInfoTab li").removeClass('ui-corner-top').addClass('ui-corner-left');
		displayVatAccount();
		toggleInvoiceAddress();
		hideShowVatNumberInput();
	}
};

jQuery(document).ready(function () {
	ACC.bindRegisterEventHandler.bindAll();
});

