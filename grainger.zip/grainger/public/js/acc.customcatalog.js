ACC.customcatalog = {

	adding_ctg: true,

	sendAddCategoryRequest: function() {

		var url = '/my-account/my-catalogs/create',
		inputError = false,
		parentCategoryCode = $("#parentcategoryid").val(),
		data = {parentCategoryCode: parentCategoryCode};
		
    	if (ACC.customcatalog.adding_ctg) {
    		if ($.trim($("#newCategoryName").val()).length > 0) {
    			data.categoryName = $("#newCategoryName").val();
    		} else {
    			inputError = true;
    		}
    	} else {
    		url = '/my-account/my-catalogs/' + parentCategoryCode + '/add';
    		data.categoryCode = $("#existCategory").val();
    	}
    	
    	if (inputError) {
    		$("#catalogError").removeClass("hidden hide");
    	} else {
    		$.ajax({
    		    type: 'post',
    		    url: url,
    		    data: data,
    		    success: function(data) {
    		    	$("#popup_add_category_modal").html(data);
    		    	if ($("#existing_error").length > 0) {
    		    		ACC.customcatalog.bindAddCategoryEvents();
    		    	} else {
    		    		location.reload();
    		    	}
    		    }
    		});
    	}
    },

	bindAddCatalogEvents: function () {
		$('#add_catalog_button').click(function (e) {
			e.preventDefault();
			ACC.customcatalog.sendAddCatalogRequest();
		});
	},

	sendAddCatalogRequest: function() {
		var categoryName = $.trim($("#newcatalogname").val());
		if(categoryName.length > 0 ){
		    $.ajax({
			    type: 'post',
			    url: '/my-account/my-catalogs/create/',
			    data: {
			        categoryName: categoryName,
			    },
			    success: function(data) {
			    	$("#popup_add_catalog_modal").html(data);
			    	if ($("#existing_error").length > 0) {
			    		ACC.customcatalog.bindAddCatalogEvents();
			    	} else {
			   			location.reload();
			    	}
			    }
			});
		} else {
			$("#catalogError").removeClass("hidden hide");
		}
	    return false;
	},

	bindAddCategoryEvents: function () {
		$("#newCategoryName").on("focusin", function(){
	    	$("#ex_ctg_tile").addClass("faded_tile");
	    	$("#new_ctg_tile").removeClass("faded_tile");
	    	ACC.customcatalog.adding_ctg = true;
		});

		$("#existCategory").on("focusin", function(){
	    	$("#ex_ctg_tile").removeClass("faded_tile");
	    	$("#new_ctg_tile").addClass("faded_tile");
	    	ACC.customcatalog.adding_ctg = false;
		});

		$("#add_category_button").click(function(e){
		    e.preventDefault();
		    ACC.customcatalog.sendAddCategoryRequest();
		});
	},

	bindRemoveCatalogEvent: function () {
		$('#remove_catalog_button').click(function (e) {
			e.preventDefault();
		    $.ajax({
			    type: 'post',
			    url: '/my-account/my-catalogs/' + $('#remove-catalog-id').val() + '/remove',
			    success: function(data) {
			   		location.reload();
			    }
			});
		    return false;
		});
	},

	createCatalog: function () {
		$.get('/my-account/my-catalogs/create', function(data) {
			$("#popup_add_catalog_modal").html(data);
			ACC.customcatalog.bindAddCatalogEvents();
			$.colorbox({
				inline: true,
				href: "#popup_add_catalog_modal",
				height: false,
				innerHeight: "150px",
				overlayClose: false,
				width: "50%",
				onComplate: function () {
					$.colorbox.resize();
					ACC.common.refreshScreenReaderBuffer();
				}
			});
		});
	},

	addCategory: function (catalogid) {
		$cat_url = '/my-account/my-catalogs/' + catalogid + '/add';
		$.ajax({
		    type: 'get',
		    url: $cat_url,
		    data: {
		    	parentCategoryCode: catalogid,
		    },
		    success: function(data) {
		    	$("#popup_add_category_modal").html(data);
		    	ACC.customcatalog.bindAddCategoryEvents();
				$.colorbox({
					inline: true,
					href: "#popup_add_category_modal",
					height: false,
					innerHeight: "180px",
					overlayClose: false,
					width: "50%",
					onComplate: function () {
						$.colorbox.resize();
						ACC.common.refreshScreenReaderBuffer();
					}
				});
		    }
		});
	},

	removeCatalog: function (catalogid) {
		var categoryurl = '/my-account/my-catalogs/remove/' + catalogid;
		$.get(categoryurl, function(data){
			$("#popup_remove_catalog_modal").html(data);
			ACC.customcatalog.bindRemoveCatalogEvent();
			$.colorbox({
				inline: true,
				href: "#popup_remove_catalog_modal",
				height: false,
				overlayClose: false,
				width: "50%"
			});
		});
		return false;
	}
};

$(document).ready(function () {

});




	