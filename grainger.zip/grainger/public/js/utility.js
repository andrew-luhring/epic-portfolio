// TODO add tests for exception, all keysvals cases, then refactor this

define (['jquery', 'angular'], function (jquery, angular) {
    "use strict";
    function Utility(){

        function finished(action, fail){
            if(action && typeof action === 'function'){
                return action();
            } else if(typeof action === "string") {
                return console.log (action);
            }else if(typeof action === 'undefined'){
            } else {
                if(fail && typeof fail === "boolean"){
                    console.warn(action);
                    return fail;
                } else {
                    throw "your action failed AND you passed a " + typeof fail + " rather than a boolean; \nstep your game up.";
                }
            }
        }

        var utility = {
            /**
             *  Generate an exception.
             * @param type
             * @param message
             * @constructor
             */
                Exception : function(isFatal, type, message){
                    if(type && message){
                        this.name = type;
                        this.message = message;
                    } else {
                        throw "a FATAL exception has occured AND even the Exception was called wrong.\n type is: "+ type + "\n message is: " + message + "\nWhat are you doing with your life? Step your game up.";
                    }
                    if(isFatal === true){
                        throw "type : " + this.name + "\n"  + this.message;
                    }
                }
            /**
             *  generates vender prefixes
             * @param $obj  :  jQuery Object
             * @param property :   property to change
             * @param val   :   value to change it to.
             * @returns {*}
             *
             *      For the record, I was hesitant to write this because css and js should not mix, but it's meant for properties that change over time.
             */
            ,   crossBrowserCssValue : function ($obj, property, val) {
                var jqO;
                if ($obj instanceof $) {
                    jqO = $obj;
                } else {
                    jqO = $ ($obj);
                }
                jqO.css ("-webkit-" + property, val);
                jqO.css ("-moz-" + property, val);
                jqO.css ("-ms-" + property, val);
                jqO.css ("-o-" + property, val);
                jqO.css (property, val);
                return jqO;
            }
            /**
             * log to html or console the keys and values of an object.
             * @param {object}
             * @param {boolean} - isSilent
             * @param {boolean} generate html
             * @returns {Function|boolean|*}
             */
            ,	keysVals : function (object, isSilent, toHtml) {
                var obj = object
                  ,   mode = isSilent;

                // TODO: dry this up and add unit tests.
                function log (thing, _mode, toHtml ) {

                    // if browser window
                    // and thing is:
                    // not silent,
                    // a string,
                    // should be converted to html : create a div, insert thing as a text node, send div to returnResult
                    if(window.document  && _mode === true  && typeof thing === 'string' && toHtml === true ){
                        var textNode = document.createTextNode(thing)
                            , divNode = document.createElement("div");
                        divNode.appendChild(textNode);
                        returnResult(divNode, true);

                    // if thing is:
                    // not silent,
                    // a string
                    // falsy toHtml value
                    // should NOT be converted to html : send returnResult the string
                    } else if (_mode === true && typeof thing === 'string' && !toHtml) {
                        returnResult(thing, toHtml);

                    // if thing is:
                    // not silent
                    // BUT thing is NOT a string
                    // this is a type error
                    } else  if (_mode === true && typeof thing !== 'string'){

                        var err = new utility.Exception(false, 'Standard Error', 'you called keysVals and passed in ' + thing + ' which is not a string');
                        console.error(err.name, err.message);
                        returnResult(false);

                    // if thing is:
                    // SILENT
                    // NOT a string
                    // this is a FATAL error
                    } else if (typeof thing !== 'string'){
                        var FATAL = new utility.Exception(true, 'Dangerously Silent Error', ' you called keysVals with silent mode on and passed in ' + thing + ' which is not a string!');

                    // if thing is:
                    // silent
                    // string
                    // all is fine,just return true.
                    } else {
                        obj.test = true;
                    }
                }
                function returnResult(thing, isHtml){
                    // if thing isn't html but is ok, add to obj.test array
                    if(isHtml !== true && typeof thing === 'string'){
                        console.log(thing);
                        obj.test += thing;
                    // if thing is html and the elements' first child is text
                    } else if (isHtml === true && thing.firstChild.nodeName === '#text'){
                        console.log(thing.childNodes.length);
                        obj.test += thing;
                        console.log(typeof thing);
                        console.log(thing.tagName , thing.firstChild.nodeName);
                    } else if(thing === false){
                        obj.test = false;
                    }
                }
                for (var i in object) {
                    if (obj.hasOwnProperty (i)) {
                        var str = i + " :  " + obj[i];
                        log (str, mode, toHtml);

                        for (var j in object[ i ]) {
                            if (obj.hasOwnProperty (j)) {
                                var str2 = "      " + j + " : " + object[ i ][ j ];
                                log (str2, mode, toHtml);
                                obj.test = "word";
                                obj.toString ("\n" + j + " : " + object[ i ][ j ]);
                            }
                        }
                    }
                }

                return obj.test;
            }
            /**
             *  creates a Pallete object- which can be color shifted over a period of time
             * @param $obj  :  jQueryObject.
             * @param transition: default: 'all 5s'
             * @param range : difference between hsl color value 1 and hsl color value 2.
             * @constructor
             *
             *
             * @Properties:
             .pallete               hsl hue value (between 0 and 360) ===>   default is randomly generated,
             .selector             value of the jQueryObject used in instantiation.
             .worklength      default is the number of objects returned by .selector ;
             .delta                 the difference between the start gradient hsl value and end gradient hsl value ====> default is range value divided by worklength value.

             Methods:

             .transition()    method that sets the length in sections the transition should last. default is transitionTime passed at instantiation.
             .colorShift(i)     requires incrementor amount. the incrementor amount means that whatever you call this method with should have its own iterator and timing sequence.
             *
             */
            ,	Pallete : function ($obj, transition, range) {
                /**
                 * @param palleteObject
                 * @param incrementBy
                 * @constructor
                 */
                function Gradient (palleteObject, incrementBy) {
                    this.start = palleteObject.pallete + palleteObject.delta + incrementBy;
                    this.end = this.start + palleteObject.range;
                }
                this.pallete = Math.floor (Math.random () * 360);
                this.selector = $obj;
                this.range = range || 45;
                this.worklength = $obj.length;
                this.delta = (function (range, worklength) {
                    if (range >= 0 && worklength >= 0) {
                        return range / worklength;
                    } else {
                        return 1;
                    }
                }) (this.range, this.worklength);
                this.transition = (function ($obj, value) {
                    var val;
                    if (value) {
                        val = value;
                    } else {
                        val = "all 5s";
                    }
                    utility.crossBrowserCssValue ($obj, "transition", val);
                }) (this, transition);
                this.colorShift = function (incrementor, isDrastic, isGradient) {
                    var incrementBy = (isDrastic) ? incrementor * (this.range ) : incrementor + (this.range )      //if (isDrastic) { incrementBy = incrementor * (this.range );} else {incrementBy = incrementor + (this.range );}
                        ,   gradient = new Gradient (this, incrementBy)
                        ,   hsl = function (hue) {  return 'hsl(' + hue + ',100%,80%)'; };
                    if (isGradient) {
                        this.selector.css ("background", "-webkit-linear-gradient(45deg, " + hsl (gradient.start) + " 0%," + hsl (gradient.end) + "100%)");
                        this.selector.css ("background", "-moz-linear-gradient(45deg, " + hsl (gradient.start) + " 0%," + hsl (gradient.end) + "100%)");
                        this.selector.css ("background", "-ms-linear-gradient(45deg, " + hsl (gradient.start) + " 0%," + hsl (gradient.end) + "100%)");
                        this.selector.css ("background", "-o-linear-gradient(45deg, " + hsl (gradient.start) + " 0%," + hsl (gradient.end) + "100%)");
                        this.selector.css ("background", "linear-gradient(45deg, " + hsl (gradient.start) + " 0%," + hsl (gradient.end) + "100%)");
                    } else {
                        this.selector.css ("background", hsl (gradient.start));
                    }
                    return this.selector.css;
                };
            }
            /**
             *   creates div with id string;
             * @param   { string }
             *
             */
            ,   testDiv : function newDiv(id){
//                console.log(id);
                var createDiv = document.createElement('div')
                    , body= document.body
                    , _testDiv;
                    createDiv.id = id;
                    _testDiv = body.appendChild(createDiv).id;

//                    , _testDiv = body.appendChild(createDiv);

                return _testDiv;
            }
            /**
             *  will log to console by default. will log to object created from string if one is passed. will silently 'log' if silent is true.
             * @param thingToLog    -    {string}
             * @param logToDom  -   {string}    :   will automatically create a new one with the string logToDom.
             * @param silent    -   {boolean}
             * @returns {boolean}
             */
            ,	log : function log(isError, thingToLog, silent){
                    if(isError === true){
                        console.warn(thingToLog);
                    }
                    if(!silent){
                        console.log(thingToLog);
                    }
            }
            /**
             *  will log to a dynamically inserted dom element by default.
             * @param isError   -   { boolean }
             * @param thingToLog    -   {string}
             * @param logToDomObj   -   { string }
             * @returns {Array}
             */
            ,   logDom : function(isError, thingToLog, logToDomObj){
                var logged = []
                ,      selector = "#"+logToDomObj
                ,      id = '#' + utility.testDiv(logToDomObj);

                // checks to make sure it's been inserted into dom correctly by making sure the text is the same as
                // thingToLog text and that the id returned by testDiv is the same as the one passed to it.
                    $(id).text(thingToLog);
                    logged.push(($(selector).text() === thingToLog) ? true : false);

                    if(isError === true){
                        $(id).addClass("error");
                        logged.push(($(selector).hasClass("error") === true) ? true : false);
                    }
                    return logged;
            }
            /**
             *  animates a change in visibility
             * @param {string}  -   jquery selector
             * @param { string }    -   classes  to add as modifiers
             * @param { string }    -   actions to take-- hide or unhide
             * @param {function} [callback] -   optional callback;
             * @returns {*}
             */
            ,   animateVisibility : function(selector, modifiers, action, callback){
                    var animation = {
                        selector : $(selector)
                    ,   modifiers : modifiers
                    ,   action : action || ''
                    };
                    var actions = (animation.action === 'unhide') ?  'hide invisible' : 'unhide visible' ;

                    animation.finished = callback;
                switch(animation.action) {
                    case "unhide":

                        jquery(selector).show(1000).removeClass(actions).addClass(modifiers);
                        return finished(animation.finished);
                    case "hide":

                        jquery(selector).removeClass(actions).addClass(modifiers).hide(1000);
                        return finished(animation.finished);
                    default:
                        // if animations.actions is not a string or nothing throw an error
                        if(typeof animation.actions !== 'undefined' ){
                            return finished("failed- " + animation.actions + " either does not exist or is not a valid action;", false);
                        }
                        return true;

                }
            }
        };
        return utility;
    }
    return new Utility();
});

/*
             function _done(result, callback){
//            var _result = result();

    return (callback) ? result(callback) : result();

//
//                if(callback){
//                    animation.callback = callback;
//                    _result = result(callback);
//                } else {
//                    _result = result();
//                }
//                return _result();
}
* */




