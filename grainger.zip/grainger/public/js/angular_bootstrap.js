
define( [
         'jquery'
    ,    'angular'
    ,   'utility'
    ]
    , function( jquery, angular, utilities){
    "use strict";
        var animateVisibility = utilities.animateVisibility
            , keysVals = utilities.keysVals
            , log = utilities.log;



        jquery(document).ready(function($){
            $(".js.csstransitions").addClass("visible");
            $(".item_container input[type=radio]").attr("ng-change", "loadNextStep()");
            $("#accountInput, #vatInput, #vat_decision").addClass("hide invisible slidein_top");
            animateVisibility("#accountInput, #vatInput, #vat_decision", "hide invisible slidein_top", "hide" );
        });

        var form = angular
        .module('formApp', [])
        .config(function ($interpolateProvider) {
            $interpolateProvider.startSymbol('[[').endSymbol(']]');
        })
        .controller("Form", function($scope){

            $scope.loadNextStep = function(){

                var account = $scope.Form.account
                    , container = "#vat_decision"
                    , $container = $(container);
                var derp = $container.hasClass("hide");

                var result = (derp === true) ?  animateVisibility($container, 'return', "unhide") : animateVisibility($container, 'return', "hide");

                if(account === 'true'){
                    console.log('yolo');
//                    jquery('#accountInput, #vat_decision').show(1000).removeClass("hide").addClass("return visible unhide");
                    animateVisibility('#accountInput, #vat_decision', 'return', "unhide");
                } else if(account === 'false'){
                    console.log('polo');
//                    jquery('#vat_decision, #vatInput').show(1000).removeClass("hide").addClass("return visible unhide");
                    animateVisibility('#vatInput, #vat_decision ', 'return', "unhide");
                } else {
                    log(true, "what happened");
                }

            };
        });



    angular.bootstrap(document, ['formApp']);

    return form;
});






/*



 form.factory('Form', function(){

 });
 //
 function Form($scope) {
 console.log($scope);
 }

 function MiniCart($scope){
 console.log($scope);
 }*/