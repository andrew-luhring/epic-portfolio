

define( [
         'jquery'
    ,    'angular'
    ,   'utility'
    ]
    , function( jquery, angular, utilities){
    "use strict";
        var  animateVisibility = utilities.animateVisibility
            , keysVals = utilities.keysVals
            , log = utilities.log
	        , form = angular.module('formApp', []);

		form.config(function ($interpolateProvider) {
            $interpolateProvider.startSymbol('[[').endSymbol(']]');
        })
        .controller("Form", function($scope){
            $scope.loadNextStep = function(){
                var account = $scope.Form.account
                    , container = "#vat_decision"
                    , $container = $(container);


                var isHidden = function(){
	                if($container.hasClass("hide")){
		                animateVisibility($container, 'return', "unhide");
		                return false;
	                } else {
		                animateVisibility($container, 'return', "hide");
		                return true;
	                }
                };
// gross.
	            if(account === 'true'){
		            //if is not hidden, hide
		            if(!isHidden){ isHidden();}
		            // hide vatInput, then check if container is hidden, if it is, unhide it, then unhide accountInput
                    animateVisibility('#vatInput', 'return', "hide", function(){
	                    if(isHidden){
		                    isHidden();
	                    }
                        animateVisibility('#accountInput', 'return', "unhide");
                    });


                } else if(account === 'false'){
		            if(!isHidden){ isHidden();}

                    animateVisibility('#accountInput,', 'return', "hide", function(){
	                    if(isHidden){
		                    isHidden();
	                    }
                        animateVisibility('#vatInput ', 'return', "unhide");
                    });

                } else {

	                console.log(" account is undefined?");
                    log(true, "what happened");

                }

            };
/*	        $scope.templates = [{
			        name: 'profile'
		        ,   url: 'ang/registration/step_one.html'
		        }, {
		            name: 'company_info'
		        ,   url: 'ang/registration/step_two.html'
	            }, {
		            name:'review'
		        ,   url: 'ang/registration/step_three.html'
	            }
	        ];*/
//	        $scope.template = $scope.templates[0];
		    $scope.talk = function(_opt){
			    if(_opt){
			        console.log("talk about what or " + _opt);
			    } else {
				    console.log("talk amongst self");
			    }
		    };
        })
        .directive("profile", function(){
			return {
				restrict : "A"
			,	transclude: true
			,	scope: {}
			,	templateUrl: 'ang/registration/step_one.html'
			};
        })
		.directive("status", function(){
				return {
					restrict : "A"
				,	transclude: true
				,	scope: {}
				,	templateUrl: 'ang/registration/registration_breadcrumb.html'
				};
		});




    angular.bootstrap(document, ['formApp']);
    return form;
});






/*

 .directive("behavior", function(){
 return function(scope, element, attributes){
 element.bind("mouseenter", function(){
 element.addClass(attributes.behavior);
 console.log("yo");
 });
 };
 }).directive("otherBehavior", function(){
 return function(sco, elem, attr){
 elem.bind("mouseleave", function(){
 elem.removeClass(attr.behavior);
 });
 };
 }).directive("talksToController", function(){
 return function(scope, element, attribute){
 element.bind("mouseenter", function(){
 //could do this:
 scope.$apply(attribute.behavior);
 //but only if you added behavior="loadNextStep() / a controller function"
 });
 };
 } );

 form.factory('Form', function(){

 });
 //
 function Form($scope) {
 console.log($scope);
 }

 function MiniCart($scope){
 console.log($scope);
 }*/