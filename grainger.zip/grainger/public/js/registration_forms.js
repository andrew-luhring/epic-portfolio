//(function(ang){


define([
    'jquery'
,    'angular_bootstrap'
], function(jquery, form){
    "use strict";
//
//
//
//    jquery(document).ready(function($){
//        $(".js.csstransitions").addClass("visible");
//        $(".item_container input[type=radio]").attr("ng-change", "Form.loadNextStep()");
//    });













});