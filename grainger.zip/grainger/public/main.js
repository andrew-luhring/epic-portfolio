requirejs.config({

    paths : {
          "address" : "js/acc.address"
        , "approval" : "js/acc.approval"
        , "autocomplete" : "js/acc.autocomplete"
        , "billingAddressForm" : "js/acc.billingAddressForm"
        , "cartpopup" : "js/acc.cartpopup"
        , "cartremoveitem" :  "js/acc.cartremoveitem"
        , "checkoutpickupdetails" : "js/acc.checkoutpickupdetails"
        , "cms" :  "js/acc.cms"
        , "common" : "js/acc.common"
        , "costcenter" : "js/acc.costcenter"
        , "currencyselector" : "js/acc.currencyselector"
        , "deliverymode" :  "js/acc.deliverymode"
        , "deliverymodedescription" : "js/acc.deliverymodedescription"
        , "forgotpassword" :  "js/acc.forgotpassword"
        , "futurelink" : "js/acc.futurelink"
        , "ieonchangefix" :  "js/acc.ieonchangefix"
        , "langselector" : "js/acc.langselector"
        , "maps": "js/acc.maps"
        , "mapscrollfix": "js/acc.mapscrollfix"
        , "mycompany": "js/acc.mycompany"
        , "negotiatequote": "js/acc.negotiatequote"
        , "paginationsort": "js/acc.paginationsort"
        , "password": "js/acc.password"
        , "paymentmethod": "js/acc.paymentmethod"
        , "paymenttype": "js/acc.paymenttype"
        , "placeorder": "js/acc.placeorder"
        , "product": "js/acc.product"
        , "productlisting": "js/acc.productlisting"
        , "productorderform": "js/acc.productorderform"
        , "producttabs": "js/acc.producttabs"
        , "quote": "js/acc.quote"
        , "refinements": "js/acc.refinements"
        , "refresh": "js/acc.refresh"
        , "replenishment": "js/acc.replenishment"
        , "search": "js/acc.search"
        , "skiplinks": "js/acc.skiplinks"
        , "stars": "js/acc.stars"
        , "stickyHeader": "js/acc.stickyHeader"
        , "storefinder": "js/acc.storefinder"
        , "termsandconditions": "js/acc.termsandconditions"
        , "userlocation": "js/acc.userlocation"
        , "excanvas-compressed": "js/excanvas-compressed"
        , "excanvas-r3.compiled": "js/excanvas-r3.compiled"
        , "fabory.register": "js/fabory.register"
        , "hybris.cms.live.edit": "js/hybris.cms.live.edit"



        , "jquery": "lib/jquery-1.7.2.min"
        , "angular": "lib/angular"
        , "ui": "lib/jquery-ui-1.8.18.min"
        , "bgiframe": "lib/jquery.bgiframe-2.1.2.min"
        , "blockUI": "lib/jquery.blockUI-2.39"
        , "bt-0.9.5-rc1": "lib/jquery.bt-0.9.5-rc1.min"
        , "colorbox": "lib/jquery.colorbox-1.3.16"
        , "colorbox_c": "lib/jquery.colorbox.custom-1.3.16"
        , "currencies": "lib/jquery.currencies.min"
        , "currencies.patch": "lib/jquery.currencies.patch"
        , "easing": "lib/jquery.easing.1.3"
        , "form": "lib/jquery.form-3.09"
        , "galleriffic": "lib/jquery.galleriffic-2.0.1"
        , "jcarousel": "lib/jquery.jcarousel-0.2.8.min"
        , "pstrength": "lib/jquery.pstrength-1.2.min"
        , "pstrength_c": "lib/jquery.pstrength.custom-1.2.0"
        , "query": "lib/jquery.query-2.1.7"
        , "scrollTo": "lib/jquery.scrollTo-1.4.2-min"
        , "slideviewer_c": "lib/jquery.slideviewer.custom.1.2"
        , "tmpl": "lib/jquery.tmpl-1.0.0pre.min"
        , "treeview": "lib/jquery.treeview"
        , "ui.datepicker.validation": "lib/jquery.ui.datepicker.validation"
        , "ui.stars": "lib/jquery.ui.stars-3.0.1.min"
        , "validate": "lib/jquery.validate"
        , "verticalscrollplus": "lib/jquery.verticalscrollplus-1.0"
        , "waitforimages": "lib/jquery.waitforimages.min"
        , "testingdoc": "js/testingdoc"
        , "waypoints": "lib/waypoints.min.1.1.5"

        // Andrew
        ,  "angular_bootstrap" : 'js/angular_bootstrap'
        ,  "jquery_bootstrap" : 'js/jquery_bootstrap'
        ,   "registration": "js/registration_forms"
        ,   "utility" : "js/utility"
    }
,     shim: {
        'angular': {
            exports : 'angular'
        }
    ,   'ui': ['jquery']
    ,   'bgiframe': ['jquery']
    ,   'blockUI' : ['jquery']
    ,   'bt' : ['jquery']
    ,   'colorbox' : ['jquery']
    ,   'colorbox_c': ['jquery']
    ,   'currencies': ['jquery']
    ,   'currencies.patch': ['jquery']
    ,   'easing': ['jquery']
    ,   'form': ['jquery']
    ,   'galleriffic': ['jquery']
    ,   'jcarousel': ['jquery']
    ,   'pstrength': ['jquery']
    ,   'pstrength_c': ['jquery']
    ,   'query': ['jquery']
    ,   'scrollTo': ['jquery']
    ,   'slideviewer_c': ['jquery']
    ,   'tmpl': ['jquery']
    ,   'treeview': ['jquery']
    ,   'ui.datepicker.validation': ['jquery']
    ,   'ui.starts': ['jquery']
    ,   'validate': ['jquery']
    ,   'verticalscrollplus': ['jquery']
    ,   'waitforimages': ['jquery']
    ,   'testingdoc': ['jquery']
    ,   'waypoints': ['jquery']
}
});


requirejs([
        'angular' ,   'jquery' ,   'registration' ]
    , function(angular, jquery, registration) {
       var ang = angular
        , jq = jquery
        , reg = registration;
    }
);







