(function(){
	"use strict";

//noinspection JSUnresolvedVariable,JSUnusedGlobalSymbols

	//  node requires

	//==============================
	// grunt
	// grunt-browserify
	// express-hbs
	// express
	//
	const express = require('express')
		, portN = 5000
		, statPort = 5001
		, hbs = require('express-hbs')
		, app = express()
		, path = require('path')
		, Server = require('./server')
		, bodyParser = require('body-parser')
		, serveStatic = require('serve-static')
		, session = require('express-session')
		, stat = express()
		, logger  = require('morgan')
		, methodOverride = require('method-override')
		, errorhandler = require('errorhandler')


	//  view paths
	//==============================
	//
	//
	//
		, viewsD = __dirname + '/views/'
		, partialsD = viewsD + 'partials/'
		, layoutsD = viewsD + 'layouts/'
		, testsD =  __dirname + 'tests/'

	//  view file paths
	//==============================
	//
	//
	//
		, publicD =  path.join(__dirname, 'public')
		, defaultF = layoutsD + 'default.hbs';
	//  Express setup.
	//==============================
	//
	//
	//
	app.use(express.static(publicD))
			.use(bodyParser())
			.use(logger('dev'))
			.use(methodOverride())
			//.use(express.static(path.join(__dirname, 'tests')))
			.use(serveStatic(path.join(__dirname, 'public')))
			.use(errorhandler());

	app.set('view engine', 'hbs')
			.set('port', process.env.PORT || portN)
			.set('cache', false)
			.set('views', viewsD);

	app.engine('hbs', hbs.express3({
		partialsDir: partialsD,
		defaultLayout: defaultF,
		layoutsDir: layoutsD
	}));

	var indx = {
	derp : {
		src : '/'
	,   id : 'swag'
	}
};
	app.get( '/' ,function (req, res) {
		res.render(partialsD + '_home.hbs', indx);
	});
	app.get( '/store' ,function (req, res) {
		res.render(partialsD + '_store.hbs', indx);
	});
	app.get( '/register' ,function (req, res) {
		res.render(partialsD + '_register.hbs', indx);
	});
	app.get( '/cart' ,function (req, res) {
		res.render(partialsD + '_cart.hbs', indx);
	});
	stat.use(serveStatic(testsD));
	stat.set('port', statPort)
			.set('cache', false);
	new Server(app);
	new Server(stat);

})();


