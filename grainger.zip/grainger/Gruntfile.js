function lintOptions(isBrowser) {
        "use strict";
	var opts = {
			laxcomma: true,
			bitwise: true,
			curly: true,
			esnext : true,
			eqeqeq: true,
			forin: true,
			latedef: true,
			newcap: true,
			noarg: true,
			nonew: false,
			undef: true,
			unused: false,
			trailing: false,
			node: true,
			smarttabs: true,
			debug: true,
			sub: true,
			supernew: true,
			browser: true,
			devel: true,
			strict: false,
			globals : {
				mocha : true
			,   describe : true
			,   it : true
			,   before : true
			,   beforeEach: true
			,   after: true
			,   afterEach : true
			,   define : true
			,   chai : true
			,   ACC : true
		}
	};
	if(isBrowser){
		opts.globals.jquery = true;
		opts.globals.jQuery = true;
		opts.globals.$ = true;
		opts.globals.angular= true;
		opts.globals.require = true;
		opts.globals.requirejs = true;
	} else {
		opts.esnext = true;
	}
	return opts;
}
// TODO update docs and readme commands to reflect these changes.
module.exports = function(grunt) {
        "use strict";
	//const
var  ASSETS_DIR =  "./public/"
	,   STYLE_DIR =  ASSETS_DIR + "css/"
	,   LESS_DIR = ASSETS_DIR + "less/"
	,   STYLEGUIDE_DIR = ASSETS_DIR + "styleguide/"
	,   JSDOC_DIR = ASSETS_DIR + "doc/"
	,   JS_DIR = ASSETS_DIR + 'js/'
	,   TEST_DIR =  'tests/'
	,   VIEWS_DIR = './'
	,   guideF  = STYLEGUIDE_DIR + "public/style.css"
	// build
	,   BUILD_DIR = ASSETS_DIR + "build/"
	,   BUILD_STYLE = BUILD_DIR + "css/"
	,   BUILD_JS = BUILD_DIR + "js/"
	,   cssF = STYLE_DIR  + "style.css"
	,   buildF = BUILD_DIR + "css/style.css"
	,   lessF = LESS_DIR + "style.less"
	,   karmacmd = 'karma start config/karma.conf.js'
	,   lesscmd = 'lessc --source-map-map-inline --source-map --source-map-rootpath=../less/ '+ lessF + ' ' + cssF
	,   gruntcmd = './node node_modules/.bin/grunt'
	,   frontendF =[ 'public/**/*.js', '!**/lib/**', 'tests/**/*.js', '!**/acc*.js',	TEST_DIR + "_*.js", '!**/jsdoc/**' ]
	,   backendF= [
	'!**/node_modules/**'
	,  '!**/public/**'
	,  '!**/grainger/**'
	,  '!**/commonjsAngular/**'
	, '!**/views/**'
	, './*.js'

	]
	,   bothF = ['public/**/*.js', '!**/lib/**', 'tests/**/*.js', '!**/acc*.js', '!**/node_modules/**', '!**/public/**']
	,   config = {
		pkg: grunt.file.readJSON('package.json')
	,   less: {
			dist : {
				files: {}
			,	options: {
					sourceMap: true
				,   dumpLineNumbers: true
				}
			}
		,   guide: {
				files: {}
			,   options: {
					sourceMap: true
				}
			}
		,   build: {files: {}}
		}
	,   shell : {
			jsdoc: {
				options: {
					stdout: true
				},
				command: 'node node_modules/.bin/jsdoc -c jsdoc_conf.json '
			}
		,   kss : {
				options: {
					stdout:true
				}
			,	"command" : "node node_modules/.bin/kss-node less --template styleguide-template/"
			}
		,   less: {
			command: lesscmd
		,   options: {
				stdout:true
			,   stderr: true
			,   failOnError: true
			}
		}
		,   only_karma: {
			options: {
				stdout: true
			}
		,   command: karmacmd
		}
		,   dev: {
				options: {
					stdout: true
				}
			,   command: [lesscmd , gruntcmd + ' karma:unit:start watch -v'].join('&')
			}
		}
	,   jshint: {
			frontend: {
				files: {
					src: [
						JS_DIR + "*.js"
					,   ASSETS_DIR + 'main.js'
					,   TEST_DIR + "_*.js"
					,   TEST_DIR + "test-main.js"
					]
				}
			,   options: lintOptions (true)
			}
		,   backend: {
				src: [
					'./*.js'
				,   'config/*.js'
				]
			,	options: lintOptions (false)
			}
		}
	,   karma: {
			unit: {
				configFile: './config/karma.conf.grunt.js'
			,	background: true
			}
		}
	,   kss: {
			options: {
				includeType: 'less'
			,   includePath: lessF
			//,   template: '/Users/yaxl047/Sites/fabory/bin/custom/fabory/faborystorefront/web/webroot/_ui/desktop/common/template'
			}
		,   dist: { files: {} }
		}
	,   clean: [STYLEGUIDE_DIR, JSDOC_DIR ]
	,   watch:{
			backend: {
				files: backendF
			,   tasks: ['jshint:backend']
			}
		,	frontend: {
				files: frontendF
			,	tasks: ['jshint:frontend']
			}
		,   style : {
				tasks: ['shell:less']
			,	files: [
					LESS_DIR + "*.less"
				,   LESS_DIR + "partials/*.less"
				]
			}
			/*   lint : {
		files : [
		bothF
		]
		,   tasks: [ 'jshint' ]
		}
		*/
		}
	};
	config["less"]["dist"]["files"][cssF] = lessF;
	config["less"]["build"]["files"][buildF] = lessF;
	config["less"]["guide"]["files"][guideF] = lessF;
	config["kss"]["dist"]["files"][STYLEGUIDE_DIR] = LESS_DIR;
	grunt.initConfig( config );
	grunt.registerTask("default", 'Lints js, generates jsdoc, compiles less, generates styleguide', ['jshint', 'jsdoc', 'less', 'build']);
	grunt.registerTask("jsdoc", "run jsdoc", ['shell:jsdoc']);
	grunt.registerTask("build", "runs jshint, compiles less, removes old documentation + styleguide, generates jsdoc documentation, generates styleguide, ", ['jshint', 'less', 'clean', 'shell:jsdoc', 'shell:kss']);
	grunt.loadNpmTasks('grunt-shell');
	grunt.loadNpmTasks('grunt-contrib-jshint');
	grunt.loadNpmTasks('grunt-karma');
	grunt.loadNpmTasks('grunt-kss');
	grunt.loadNpmTasks('grunt-contrib-requirejs');
	grunt.loadNpmTasks('grunt-contrib-clean');
	grunt.loadNpmTasks('grunt-contrib-less');
	grunt.registerTask("only_karma", "only run karma", function(){
	grunt.task.run('shell:only_karma');
	});
	grunt.registerTask("style", "generate styleguide", function(){
		grunt.task.run('shell:kss', 'less:guide');
	});
	grunt.loadNpmTasks('grunt-contrib-watch');
	grunt.registerTask("browser", "run karma and watch", function(){
            config["watch"]['karma'] = {
                files : [
                        TEST_DIR + "_*.js"
                    ,	JS_DIR + "*.js"
                    ,	ASSETS_DIR + "main.js"
                    ,	TEST_DIR + "test-main.js"
                ]
            ,	tasks: ['karma:unit:run']
            };
            grunt.task.run('karma:unit:start', 'watch');
        });
};
