
Minimum Marketable Features
=====================

1.)     The site and all of it's linked to sites need to all work. <== **current**
		*       (includes site glitches/problems)
2.)     Update portfolio content.
3.)     Refactor JavaScript.
4.)     Add new features
		*       Aria-roles, tooltips, angular stuff.






*   Fix the footer button click glitch (have to click twice?)

