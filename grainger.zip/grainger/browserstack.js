var webdriver = require('browserstack-webdriver');

// Input capabilities
var capabilities = {
    'browserstack.local' : 'true',
    'browserstack.localIdentifier' : 'local',
    'browserstack.user' : 'andrewluhring',
    'browserstack.key' : 'YxpsTbcsxNpx9mpUpd2a',
    'os' : 'Windows',
    'os_version' : 'XP',
    'browser' : 'IE',
    'browser_version' : '7.0',
    'resolution' : '1024x768'
};

    var driver = new webdriver.Builder().
    usingServer('http://hub.browserstack.com/wd/hub').
    withCapabilities(capabilities).
    build();

driver.get('http://www.google.com/ncr');
driver.findElement(webdriver.By.name('q')).sendKeys('BrowserStack');
driver.findElement(webdriver.By.name('btnG')).click();

driver.getTitle().then(function(title) {
	console.log(title);
    });

driver.quit();
