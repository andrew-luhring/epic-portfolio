
var  BASE_DIR =  "../"
    ,   ASSETS_DIR =  BASE_DIR + "public/"
	,   JS_DIR = ASSETS_DIR + 'js/'
	,   TEST_DIR =  BASE_DIR + 'tests/';

exports.config = {

	specs : [
		TEST_DIR + 'test-main.js'
	]
	,   baseUrl: 'http://localhost:5000'
}