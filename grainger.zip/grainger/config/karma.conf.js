
module.exports = function (config) {
	const ASSETS_DIR = './public/'
		,   JS_DIR  = ASSETS_DIR +'js/'
		,   COMMON_DIR  = JS_DIR +'common/'
		,   LESS_DIR = ASSETS_DIR + 'less/'
		,   LIB_DIR  = ASSETS_DIR +'lib/'
		,   TEST_DIR  = 'tests/'
		,   RECURSIVE_TEST_DIR  =  TEST_DIR + '**/'
	// for testing css is stored in test_dir
		,   CSS_DIR = TEST_DIR
		,   CSS_F = CSS_DIR + 'style.css'
		,   MAIN_F = ASSETS_DIR + 'main.js'
		,   TEST_F = TEST_DIR + 'test-main.js'
		,   GRUNT_TEST_F = TEST_DIR + 'grunt-test-main.js';


	const GLOB = {
		lib : LIB_DIR + '*.js'
		,   js : JS_DIR + '*.js'
		,   common : COMMON_DIR + '*.js'
//,   tests: TEST_DIR + '_*.js'
		,   recursive : RECURSIVE_TEST_DIR + '_*.js'
		,   less : LESS_DIR + '*.less'
	};

	config.set ({
		basePath: '../',
		frameworks: ['mocha', 'requirejs', 'chai'],
		files: [
			CSS_F,
			{pattern: GLOB.lib, included: false},
			{pattern: GLOB.js, included: false},
//			{pattern: GLOB.tests, included: false},
			{pattern: GLOB.recursive, included: false},
            'config/mocha.window.js',
            TEST_F
		],
		exclude: [
//			'**/*min*',
			'**/*ignore*',
            'public/js/acc.*',
			'tests/e2e/*',
			MAIN_F,
			GRUNT_TEST_F

		],
		htmlReporter: {
			outputDir: TEST_DIR+ 'karma'
        ,   templatePath: TEST_DIR + 'index.html'
		},
		reporters: [/*'growl', */'mocha', 'html'],
        port: 9876,
        colors: true,
        captureTimeout: 60000,
        singleRun: false,

//        diff from grunt.
        logLevel: config.LOG_INFO,
//        logLevel: config.LOG_DEBUG,
        autoWatch: true,
        preprocessors: {
	        '../public/main.js' : ['coverage']
        },
        browsers: ['Chrome'/*, 'Firefox', 'PhantomJS', 'IE', 'Safari'*/]
	});
};
