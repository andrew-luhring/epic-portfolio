/*jshint expr: true, undef: true */





var tests = []
    ,   regex = /(tests\/)(_.*\.js)/
    ,   recursive = /(tests\/)(.*\/)(_.*\.js)/
    ,   not = /(.[_])*((^(?:(?!ignore).)*)(js))/;

for (var file in window.__karma__.files) {
//    console.log(recursive.test(file) + " " + file);

    if (regex.test(file)  || recursive.test(file) && not.test(file) ) {
//        console.log("******************************");
//        console.log("testing: " + file);
//        console.log("******************************");
        tests.push(file);
    }
}

const ASSETS_DIR = '../public/'
		,	BASE_DIR = '/base/public/'

		,   JS_DIR  = ASSETS_DIR +'js/'
		,   LESS_DIR = ASSETS_DIR + 'less/'
		,   LIB_DIR  = ASSETS_DIR +'lib/'
		,   TEST_DIR  = ASSETS_DIR +'tests/'
		,   RECURSIVE_TEST_DIR  =  TEST_DIR + '**/'
// for testing css is stored in test_dir
		,   CSS_DIR = TEST_DIR
		,   CSS_F = CSS_DIR + 'style.css'
		,   MAIN_F = ASSETS_DIR + 'main.js'
		,   TEST_F = TEST_DIR + 'test-main.js';

//,   "utility" : "../public/js/utility"
//, "jquery": "lib/jquery"


require.config({
    baseUrl: BASE_DIR,
    paths : {
        "address" : "../js/acc.address"
        , "approval" : "../js/acc.approval"
        , "autocomplete" : "../js/acc.autocomplete"
        , "billingAddressForm" : "../js/acc.billingAddressForm"
        , "cartpopup" : "../js/acc.cartpopup"
        , "cartremoveitem" :  "../js/acc.cartremoveitem"
        , "checkoutpickupdetails" : "../js/acc.checkoutpickupdetails"
        , "cms" :  "../js/acc.cms"
        , "common" : "../js/acc.common"
        , "costcenter" : "../js/acc.costcenter"
        , "currencyselector" : "../js/acc.currencyselector"
        , "deliverymode" :  "../js/acc.deliverymode"
        , "deliverymodedescription" : "../js/acc.deliverymodedescription"
        , "forgotpassword" :  "../js/acc.forgotpassword"
        , "futurelink" : "../js/acc.futurelink"
        , "ieonchangefix" :  "../js/acc.ieonchangefix"
        , "langselector" : "../js/acc.langselector"
        , "maps": "../js/acc.maps"
        , "mapscrollfix": "../js/acc.mapscrollfix"
        , "mycompany": "../js/acc.mycompany"
        , "negotiatequote": "../js/acc.negotiatequote"
        , "paginationsort": "../js/acc.paginationsort"
        , "password": "../js/acc.password"
        , "paymentmethod": "../js/acc.paymentmethod"
        , "paymenttype": "../js/acc.paymenttype"
        , "placeorder": "../js/acc.placeorder"
        , "product": "../js/acc.product"
        , "productlisting": "../js/acc.productlisting"
        , "productorderform": "../js/acc.productorderform"
        , "producttabs": "../js/acc.producttabs"
        , "quote": "../js/acc.quote"
        , "refinements": "../js/acc.refinements"
        , "refresh": "../js/acc.refresh"
        , "replenishment": "../js/acc.replenishment"
        , "search": "../js/acc.search"
        , "skiplinks": "../js/acc.skiplinks"
        , "stars": "../js/acc.stars"
        , "stickyHeader": "../js/acc.stickyHeader"
        , "storefinder": "../js/acc.storefinder"
        , "termsandconditions": "../js/acc.termsandconditions"
        , "userlocation": "../js/acc.userlocation"
        , "excanvas-compressed": "../js/excanvas-compressed"
        , "excanvas-r3.compiled": "../js/excanvas-r3.compiled"
        , "fabory.register": "../js/fabory.register"
        , "hybris.cms.live.edit": "../js/hybris.cms.live.edit"


        //Andrew Scripts
        ,  "registration": "../public/js/registration_forms"
        ,  "angular_bootstrap" : '../public/js/angular_bootstrap'
        ,  "jquery_bootstrap" : '../public/js/jquery_bootstrap'
        ,   "utility" : "../public/js/utility"
        // Andrew frameworks
	    , "jquery": "lib/jquery"
//        , "jquery": "public/lib/jquery"
        , "jqueryMigrate" : "lib/jquery-migrate"
        , "angular": "lib/angular"
        , "angularMin": "lib/angular.min"
        , 'angularAnimate' : "lib/angular-animate"
        , 'angularTouch' : "lib/angular-touch"
        , 'chai': 'lib/chai'
        , 'chai_jq' : 'lib/chai-jq'
        , 'sinon': 'lib/sinon'
        , 'chai_things': 'lib/chai-things'
//        , 'chai_change': 'chai-change'
        , 'chai_as_promised': 'lib/chai-as-promised'
        , 'sinon_chai': 'lib/sinon-chai'
        , 'sinon_timers': 'lib/sinon-timers'
        , 'mocha' : 'lib/mocha'


        // Andrew tests
        //  not Andrew frameworks:
        , "ui": "jquery-ui-1.8.18.min"
        , "bgiframe": "jquery.bgiframe-2.1.2.min"
        , "blockUI": "jquery.blockUI-2.39"
        , "bt": "jquery.bt-0.9.5-rc1.min"
        , "colorbox": "jquery.colorbox-1.3.16"
        , "colorbox_c": "jquery.colorbox.custom-1.3.16"
        , "currencies": "jquery.currencies.min"
        , "currencies.patch": "jquery.currencies.patch"
        , "easing": "jquery.easing.1.3"
        , "form": "jquery.form-3.09"
        , "galleriffic": "jquery.galleriffic-2.0.1"
        , "jcarousel": "jquery.jcarousel-0.2.8.min"
        , "pstrength": "jquery.pstrength-1.2.min"
        , "pstrength_c": "jquery.pstrength.custom-1.2.0"
        , "query": "jquery.query-2.1.7"
        , "scrollTo": "jquery.scrollTo-1.4.2-min"
        , "slideviewer_c": "jquery.slideviewer.custom.1.2"
        , "tmpl": "jquery.tmpl-1.0.0pre.min"
        , "treeview": "jquery.treeview"
        , "ui.datepicker.validation": "jquery.ui.datepicker.validation"
        , "ui.stars": "jquery.ui.stars-3.0.1.min"
        , "validate": "jquery.validate"
        , "verticalscrollplus": "jquery.verticalscrollplus-1.0"
        , "waitforimages": "jquery.waitforimages.min"
        , "testingdoc": "../js/testingdoc"
        , "waypoints": "waypoints.min.1.1.5"
    }
,   shim: {
            sinon : { exports: 'sinon' }
        ,   'angular' : {'exports' : 'angular'}
        ,   'angularRoute': ['angular']
        ,   'chai_things': ['chai']
//		,   'chai_change': ['chai']

        // not andrew:
    ,    'ui': ['jquery']
    ,   'bgiframe': ['jquery']
    ,   'blockUI' : ['jquery']
    ,   'bt' : ['jquery']
    ,   'colorbox' : ['jquery']
    ,   'colorbox_c': ['jquery']
    ,   'currencies': ['jquery']
    ,   'currencies.patch': ['jquery']
    ,   'easing': ['jquery']
    ,   'form': ['jquery']
    ,   'galleriffic': ['jquery']
    ,   'jcarousel': ['jquery']
    ,   'pstrength': ['jquery']
    ,   'pstrength_c': ['jquery']
    ,   'query': ['jquery']
    ,   'scrollTo': ['jquery']
    ,   'slideviewer_c': ['jquery']
    ,   'tmpl': ['jquery']
    ,   'treeview': ['jquery']
    ,   'ui.datepicker.validation': ['jquery']
    ,   'ui.starts': ['jquery']
    ,   'validate': ['jquery']
    ,   'verticalscrollplus': ['jquery']
    ,   'waitforimages': ['jquery']
    ,   'testingdoc': ['jquery']
    ,   'waypoints': ['jquery']
    }
,   deps: tests
    // start test run, once Require.js is done
,   callback: window.__karma__.start
});

require([
    'jquery'
,   'angular'
,   'registration'
    ], function(jquery, angular, registration) {

});