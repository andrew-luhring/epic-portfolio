describe("hello-protractor", function(){
	"use strict";
	var ptor = protractor.getInstance();
	describe("index", function(){
		ptor.get('/#');
		expect(ptor.getTitle()).toBe('helo');
	});
});